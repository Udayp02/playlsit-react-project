import { useState, useEffect, useContext } from "react";
import { useParams } from "react-router-dom";
import { ThemeContext } from "../contexts/ThemeContext";
import { CartContext } from "../contexts/CartContext";

const ProductDetail = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { darkMode } = useContext(ThemeContext);
  const { dispatch } = useContext(CartContext);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        setLoading(true);
        const response = await fetch(`https://fakestoreapi.com/products/${id}`);
        const data = await response.json();
        setProduct(data);
        setLoading(false);
      } catch (err) {
        setError('Failed to fetch product details.');
        setLoading(false);
      }
    };
    fetchProduct();
  }, [id]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="spinner h-8 w-8 border-4 border-blue-500 rounded-full border-t-transparent"></div>
      </div>
    );
  }

  if (error) {
    return <div className="p-4 bg-red-100 text-red-700 rounded">{error}</div>;
  }

  if (!product) {
    return <div className="text-center py-8">Product not found.</div>;
  }

  return (
    <div className={`p-4 md:p-8 rounded-lg ${darkMode ? 'bg-gray-800' : 'bg-white'} shadow-md`}>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="flex justify-center">
          <img 
            src={product.image || `https://placehold.co/600x600?text=${product.title.split(' ').join('+')}`} 
            alt={product.title} 
            className="w-full max-h-96 object-contain"
            onError={(e) => {
              e.target.src = `https://placehold.co/600x600?text=${product.title.split(' ').join('+')}`;
            }}
          />
        </div>
        <div>
          <h1 className="text-2xl md:text-3xl font-bold mb-2">{product.title}</h1>
          <div className="flex items-center mb-4">
            <div className="flex text-yellow-400 mr-2">
              {[...Array(5)].map((_, i) => (
                <i 
                  key={i} 
                  className={`fas fa-star${i < Math.floor(product.rating?.rate || 0) ? '' : '-half-alt'}`}
                ></i>
              ))}
            </div>
            <span className="text-gray-500">({product.rating?.count || 0} reviews)</span>
          </div>
          <p className="text-3xl font-bold mb-4">${product.price}</p>
          <p className="mb-4">{product.description}</p>
          <div className="flex items-center mb-6">
            <label className="mr-2">Quantity:</label>
            <select
              className="p-2 border rounded"
              value={quantity}
              onChange={(e) => setQuantity(parseInt(e.target.value))}
            >
              {[1, 2, 3, 4, 5].map(num => (
                <option key={num} value={num}>{num}</option>
              ))}
            </select>
          </div>
          <div className="flex space-x-4">
            <button
              onClick={() => {
                dispatch({
                  type: 'ADD_TO_CART',
                  payload: { ...product, quantity }
                });
              }}
              className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-6 rounded"
            >
              Add to Cart
            </button>
            <button className="bg-gray-200 hover:bg-gray-300 text-gray-800 py-2 px-6 rounded dark:bg-gray-700 dark:hover:bg-gray-600">
              Buy Now
            </button>
          </div>
          <div className="mt-8 pt-4 border-t">
            <h3 className="font-semibold mb-2">Details</h3>
            <ul>
              <li className="flex justify-between py-1 border-b">
                <span>Category</span>
                <span>{product.category}</span>
              </li>
              <li className="flex justify-between py-1 border-b">
                <span>Availability</span>
                <span>In Stock</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;