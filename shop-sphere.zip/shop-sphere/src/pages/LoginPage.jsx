import { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../contexts/AuthContext";
import { ThemeContext } from "../contexts/ThemeContext";

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { login } = useContext(AuthContext);
  const { darkMode } = useContext(ThemeContext);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    setTimeout(() => {
      if (email && password) {
        login();
        navigate('/');
      } else {
        setError('Please enter both email and password');
      }
      setLoading(false);
    }, 1000);
  };

  return (
    <div className={`min-h-screen flex items-center justify-center ${darkMode 
      ? "bg-gradient-to-br from-gray-900 via-gray-800 to-gray-700" 
      : "bg-gradient-to-br from-blue-100 via-white to-pink-100"}`}>
      <div className={`w-full max-w-md p-8 rounded-2xl shadow-2xl border 
        ${darkMode 
          ? "bg-gray-900 border-gray-700" 
          : "bg-white border-blue-100"}`}>
        <h2 className={`text-3xl font-extrabold mb-6 text-center tracking-tight 
          ${darkMode ? "text-white" : "text-blue-700"}`}>
          Welcome Back
        </h2>
        {error && (
          <div className="p-2 bg-red-100 text-red-700 rounded mb-4 text-center font-semibold">
            {error}
          </div>
        )}
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className={`block mb-1 font-semibold ${darkMode ? "text-gray-200" : "text-gray-700"}`}>Email</label>
            <input
              type="email"
              className={`w-full p-3 rounded-lg border focus:outline-none focus:ring-2 transition
                ${darkMode 
                  ? "bg-gray-800 border-gray-700 text-white focus:ring-blue-500" 
                  : "bg-blue-50 border-blue-200 text-gray-800 focus:ring-blue-400"}`}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoFocus
            />
          </div>
          <div className="mb-6">
            <label className={`block mb-1 font-semibold ${darkMode ? "text-gray-200" : "text-gray-700"}`}>Password</label>
            <input
              type="password"
              className={`w-full p-3 rounded-lg border focus:outline-none focus:ring-2 transition
                ${darkMode 
                  ? "bg-gray-800 border-gray-700 text-white focus:ring-blue-500" 
                  : "bg-blue-50 border-blue-200 text-gray-800 focus:ring-blue-400"}`}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 text-white font-bold py-3 rounded-lg shadow-lg flex justify-center items-center transition"
          >
            {loading ? (
              <>
                <div className="spinner h-5 w-5 border-2 border-white rounded-full border-t-transparent mr-2"></div>
                Logging in...
              </>
            ) : (
              'Login'
            )}
          </button>
        </form>
        <div className="mt-6 text-center">
          <p className={`${darkMode ? "text-gray-300" : "text-gray-600"}`}>
            Don't have an account?{" "}
            <span
              className="text-blue-500 font-semibold cursor-pointer hover:underline"
              onClick={() => navigate("/register")}
            >
              Sign up
            </span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;