import { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { CartContext } from "../contexts/CartContext";
import { ThemeContext } from "../contexts/ThemeContext";
import { AuthContext } from "../contexts/AuthContext";

const CartPage = () => {
  const { cart, dispatch } = useContext(CartContext);
  const { darkMode } = useContext(ThemeContext);
  const { isLoggedIn } = useContext(AuthContext);
  const navigate = useNavigate();
  const [checkoutLoading, setCheckoutLoading] = useState(false);

  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const updateQuantity = (id, quantity) => {
    if (quantity === 0) {
      dispatch({ type: 'REMOVE_FROM_CART', payload: id });
    } else {
      dispatch({ type: 'UPDATE_QUANTITY', payload: { id, quantity } });
    }
  };

  const handleCheckout = () => {
    setCheckoutLoading(true);
    if (!isLoggedIn) {
      navigate('/login');
      return;
    }
    setTimeout(() => {
      dispatch({ type: 'CLEAR_CART' });
      setCheckoutLoading(false);
      alert('Order placed successfully! Thank you for your purchase.');
    }, 1500);
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Your Shopping Cart</h1>
      {cart.length === 0 ? (
        <div className="text-center py-12">
          <img 
            src="https://placehold.co/600x400" 
            alt="Empty shopping cart" 
            className="mx-auto mb-4"
          />
          <h3 className="text-xl font-semibold mb-2">Your cart is empty</h3>
          <p className="text-gray-500 mb-4">Looks like you haven't added anything to your cart yet.</p>
          <Link to="/" className="bg-blue-500 hover:bg-blue-600 text-white py-2 px-6 rounded">
            Continue Shopping
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className={`p-4 rounded-lg ${darkMode ? 'bg-gray-800' : 'bg-white'} shadow-md`}>
              {cart.map(item => (
                <div key={item.id} className="flex flex-col sm:flex-row gap-4 py-4 border-b last:border-0">
                  <div className="flex-shrink-0 w-32 h-32">
                    <img 
                      src={item.image || `https://placehold.co/600x600?text=${item.title.split(' ').join('+')}`} 
                      alt={item.title} 
                      className="w-full h-full object-contain"
                      onError={(e) => {
                        e.target.src = `https://placehold.co/600x600?text=${item.title.split(' ').join('+')}`;
                      }}
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold">{item.title}</h3>
                    <p className="text-gray-500">${item.price}</p>
                    <div className="flex items-center mt-2">
                      <button 
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="w-8 h-8 flex items-center justify-center border rounded"
                      >
                        -
                      </button>
                      <span className="mx-2 w-8 text-center">{item.quantity}</span>
                      <button 
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="w-8 h-8 flex items-center justify-center border rounded"
                      >
                        +
                      </button>
                    </div>
                  </div>
                  <div className="flex flex-col items-end justify-between">
                    <p className="font-semibold">${(item.price * item.quantity).toFixed(2)}</p>
                    <button 
                      onClick={() => dispatch({ type: 'REMOVE_FROM_CART', payload: item.id })}
                      className="text-red-500 hover:text-red-700"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div>
            <div className={`p-4 rounded-lg ${darkMode ? 'bg-gray-800' : 'bg-white'} shadow-md`}>
              <h2 className="text-xl font-bold mb-4">Order Summary</h2>
              <div className="space-y-2 mb-4">
                <div className="flex justify-between">
                  <span>Subtotal ({totalItems} items)</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Shipping</span>
                  <span>FREE</span>
                </div>
                <div className="flex justify-between border-t pt-2">
                  <span className="font-semibold">Total</span>
                  <span className="font-semibold">${subtotal.toFixed(2)}</span>
                </div>
              </div>
              <button
                onClick={handleCheckout}
                disabled={checkoutLoading}
                className="w-full bg-green-500 hover:bg-green-600 text-white py-2 px-4 rounded flex justify-center items-center"
              >
                {checkoutLoading ? (
                  <>
                    <div className="spinner h-4 w-4 border-2 border-white rounded-full border-t-transparent mr-2"></div>
                    Processing...
                  </>
                ) : (
                  'Proceed to Checkout'
                )}
              </button>
            </div>
            <div className={`p-4 rounded-lg ${darkMode ? 'bg-gray-800' : 'bg-white'} shadow-md mt-4`}>
              <h3 className="font-semibold mb-2">Promo Code</h3>
              <div className="flex">
                <input 
                  type="text" 
                  placeholder="Enter promo code" 
                  className="flex-1 p-2 border rounded-l"
                />
                <button className="bg-gray-200 hover:bg-gray-300 text-gray-800 p-2 rounded-r dark:bg-gray-700 dark:hover:bg-gray-600">
                  Apply
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CartPage;