import { useContext } from "react";
import { ThemeContext } from "../contexts/ThemeContext";

const ProductSkeleton = () => {
  const { darkMode } = useContext(ThemeContext);

  return (
    <div className={`card rounded-lg shadow-md overflow-hidden ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
      <div className="h-48 skeleton"></div>
      <div className="p-4">
        <div className="h-6 w-3/4 skeleton mb-2 rounded"></div>
        <div className="h-5 w-1/2 skeleton mb-2 rounded"></div>
        <div className="h-8 w-full skeleton rounded"></div>
      </div>
    </div>
  );
};

export default ProductSkeleton;