import { useContext } from "react";
import { ThemeContext } from "../contexts/ThemeContext";
import { CartContext } from "../contexts/CartContext";

const ProductCard = ({ product }) => {
  const { darkMode } = useContext(ThemeContext);
  const { dispatch } = useContext(CartContext);

  return (
    <div className={`card rounded-lg shadow-md overflow-hidden ${darkMode ? 'bg-gray-800' : 'bg-white'} transition-all duration-200 hover:shadow-lg`}>
      <div className="h-48 overflow-hidden">
        <img 
          src={product.image || `https://placehold.co/600x400?text=${product.title.split(' ').join('+')}`} 
          alt={product.title} 
          className="w-full h-full object-cover"
          onError={(e) => {
            e.target.src = `https://placehold.co/600x400?text=${product.title.split(' ').join('+')}`;
          }}
        />
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold truncate">{product.title}</h3>
        <div className="flex justify-between items-center mt-2">
          <span className="text-lg font-bold">${product.price}</span>
          <button 
            onClick={() => dispatch({ type: 'ADD_TO_CART', payload: product })}
            className="bg-blue-500 hover:bg-blue-600 text-white py-1 px-3 rounded text-sm"
          >
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;