import { useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ThemeContext } from "../contexts/ThemeContext";
import { AuthContext } from "../contexts/AuthContext";
import { CartContext } from "../contexts/CartContext";

const Navbar = () => {
  const { darkMode, toggleDarkMode } = useContext(ThemeContext);
  const { isLoggedIn, logout } = useContext(AuthContext);
  const { cart } = useContext(CartContext);
  const navigate = useNavigate();

  return (
    <nav
      className={`py-3 shadow-lg sticky top-0 z-50 transition-colors duration-300 backdrop-blur-md bg-opacity-80 ${
        darkMode ? "bg-gray-900/90 text-white" : "bg-white/90 text-gray-800"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 flex justify-between items-center">
        {/* Logo */}
        <Link
          to="/"
          className="text-3xl font-black tracking-tight flex items-center gap-1 hover:scale-105 hover:text-blue-600 transition-transform duration-200"
        >
          <span className="text-blue-600 drop-shadow">Shop</span>
          <span className="text-indigo-500 drop-shadow">Sphere</span>
        </Link>

        {/* Controls */}
        <div className="flex items-center space-x-4">
          {/* Dark mode toggle */}
          <button
            onClick={toggleDarkMode}
            className="p-2 rounded-full hover:bg-blue-100 dark:hover:bg-gray-700 transition"
            aria-label="Toggle dark mode"
          >
            {darkMode ? (
              <i className="fas fa-sun text-yellow-400"></i>
            ) : (
              <i className="fas fa-moon text-gray-700"></i>
            )}
          </button>

          {/* Auth */}
          {isLoggedIn ? (
            <button
              onClick={logout}
              className="bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600 text-white font-semibold py-1.5 px-5 rounded-full shadow transition"
            >
              Logout
            </button>
          ) : (
            <Link
              to="/login"
              className="bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 text-white font-semibold py-1.5 px-5 rounded-full shadow transition"
            >
              Login
            </Link>
          )}

          {/* Cart Icon */}
          <Link to="/cart" className="relative group ml-2">
            <i className="fas fa-shopping-cart text-2xl group-hover:text-blue-600 transition" />
            {cart.length > 0 && (
              <span className="absolute -top-2 -right-2 bg-gradient-to-r from-red-500 to-pink-500 text-white text-xs font-bold rounded-full w-6 h-6 flex items-center justify-center border-2 border-white shadow-lg animate-bounce">
                {cart.reduce((total, item) => total + item.quantity, 0)}
              </span>
            )}
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;